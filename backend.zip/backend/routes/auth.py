from datetime import datetime, timezone
from flask import Blueprint, jsonify, request
from flask_jwt_extended import create_access_token, get_jwt, jwt_required
from werkzeug.security import check_password_hash, generate_password_hash
from pymongo.errors import DuplicateKeyError

from db import db
from models.user import serialize_user, build_user
from config import Config 



auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


def ensure_admin_user():
    """Create the initial HR account only when ADMIN_PASSWORD is configured."""

    if not Config.ADMIN_PASSWORD:
        return

    existing = db.users.find_one({
        "username": Config.ADMIN_EMPLOYEE_ID.lower()
    })

    if existing:
        return

    now = datetime.now(timezone.utc)

    user = build_user(
        Config.ADMIN_EMPLOYEE_ID,
        Config.ADMIN_NAME,
        Config.ADMIN_PASSWORD,
        "HR_ADMIN",
        Config.ADMIN_EMPLOYEE_ID,
        Config.ADMIN_DEPARTMENT,
    )

    employee = {
        "employeeId": Config.ADMIN_EMPLOYEE_ID,
        "name": Config.ADMIN_NAME,
        "department": Config.ADMIN_DEPARTMENT,
        "designation": "HR Administrator",
        "reportingManager": "",
        "email": "",
        "status": "Active",
        "createdAt": now,
        "updatedAt": now,
    }

    try:
        db.employees.update_one(
            {"employeeId": Config.ADMIN_EMPLOYEE_ID},
            {"$setOnInsert": employee},
            upsert=True,
        )

        db.users.insert_one(user)

    except DuplicateKeyError:
        pass


@auth_bp.post("/signup")
def signup():
    payload = request.get_json(silent=True) or {}
    required = ["employeeId", "name", "email", "mobile", "password", "department", "designation", "role"]
    missing = [field for field in required if not str(payload.get(field, "")).strip()]
    if missing:
        return jsonify({"message": "Please fill all required fields", "fields": missing}), 400

    employee_id = str(payload["employeeId"]).strip().upper()
    name = str(payload["name"]).strip()
    email = str(payload["email"]).strip().lower()
    mobile = "".join(ch for ch in str(payload.get("mobile", "")) if ch.isdigit())
    if len(mobile) < 10:
        return jsonify({"message": "Please enter a valid mobile number with at least 10 digits"}), 400
    password = str(payload["password"])
    department = str(payload["department"]).strip()
    designation = str(payload["designation"]).strip()
    requested_role = str(payload["role"]).strip().upper()
    role = {"ADMIN": "HR_ADMIN", "HR_ADMIN": "HR_ADMIN", "MANAGER": "MANAGER", "EMPLOYEE": "EMPLOYEE"}.get(requested_role)

    if role is None:
        return jsonify({"message": "Role must be Admin, Manager or Employee"}), 400
    if len(password) < 8:
        return jsonify({"message": "Password must be at least 8 characters"}), 400

    from routes.departments import DEPARTMENTS
    if department not in DEPARTMENTS:
        return jsonify({"message": "Please select a valid department"}), 400

    if db.users.find_one({"username": employee_id.lower()}) or db.employees.find_one({"employeeId": employee_id}):
        return jsonify({"message": "Employee ID is already registered"}), 409

    now = datetime.now(timezone.utc)
    employee = {
        "employeeId": employee_id, "name": name, "department": department,
        "designation": designation, "reportingManager": str(payload.get("reportingManager", "")).strip(),
        "email": email, "mobile": mobile, "status": "Active", "createdAt": now, "updatedAt": now,
        "registeredBy": "SELF", "accountRole": role,
    }
    user = build_user(employee_id, name, password, role, employee_id, department)
    try:
        db.employees.insert_one(employee)
        db.users.insert_one(user)
    except DuplicateKeyError:
        db.employees.delete_one({"employeeId": employee_id, "registeredBy": "SELF"})
        return jsonify({"message": "Employee ID is already registered"}), 409
    except Exception:
        db.employees.delete_one({"employeeId": employee_id, "registeredBy": "SELF"})
        return jsonify({"message": "Unable to complete signup"}), 500

    return jsonify({"message": "Signup successful", "employeeId": employee_id, "role": role}), 201


@auth_bp.post("/login")
def login():
    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip().lower()
    password = str(payload.get("password", ""))

    if not username or not password:
        return jsonify({"message": "Employee ID and password are required"}), 400

    user = db.users.find_one({"username": username})

    if not user or not check_password_hash(user.get("passwordHash", ""), password):
        return jsonify({"message": "Invalid Employee ID or password"}), 401

    if user.get("role") == "EMPLOYEE":
        employee = db.employees.find_one({"employeeId": user.get("employeeId")})
        if not employee or employee.get("status", "Active") != "Active":
            return jsonify({"message": "This employee account is inactive"}), 403

    token = create_access_token(
        identity=str(user["_id"]),
        additional_claims={
            "role": user["role"],
            "employeeId": user.get("employeeId"),
            "department": user.get("department"),
        },
    )

    user_data = serialize_user(user)
    employee = db.employees.find_one({"employeeId": user.get("employeeId")}) or {}
    user_data["email"] = employee.get("email") or user.get("email") or ""
    user_data["designation"] = employee.get("designation") or user.get("designation") or ""
    return jsonify({
        "accessToken": token,
        "user": user_data,
    })


@auth_bp.get("/me")
@jwt_required()
def me():
    from bson import ObjectId
    user_id = get_jwt().get("sub")
    try:
        user = db.users.find_one({"_id": ObjectId(user_id)})
    except Exception:
        user = None

    if not user:
        return jsonify({"message": "User not found"}), 404

    user_data = serialize_user(user)
    employee = db.employees.find_one({"employeeId": user.get("employeeId")}) or {}
    user_data["email"] = employee.get("email") or user.get("email") or ""
    user_data["designation"] = employee.get("designation") or user.get("designation") or ""
    return jsonify(user_data)


@auth_bp.put("/password")
@jwt_required()
def change_password():
    payload = request.get_json(silent=True) or {}
    current = str(payload.get("currentPassword", ""))
    new_password = str(payload.get("newPassword", ""))

    if not current or not new_password:
        return jsonify({"message": "Current password and new password are required"}), 400
    if len(new_password) < 8:
        return jsonify({"message": "New password must be at least 8 characters"}), 400

    from bson import ObjectId
    try:
        user = db.users.find_one({"_id": ObjectId(get_jwt().get("sub"))})
    except Exception:
        user = None

    if not user or not check_password_hash(user.get("passwordHash", ""), current):
        return jsonify({"message": "Current password is incorrect"}), 401

    db.users.update_one(
        {"_id": user["_id"]},
        {
            "$set": {
                "passwordHash": generate_password_hash(new_password),
                "updatedAt": datetime.now(timezone.utc),
            }
        },
    )
    return jsonify({"message": "Password changed successfully. Please sign in again."})


@auth_bp.post("/password/forgot")
def forgot_password():
    """Reset a password after matching the employee ID and registered mobile.

    This flow intentionally sends no email or OTP. It requires both identifiers
    to match the employee record; accounts without a registered mobile must be
    updated by an administrator before this recovery method can be used.
    """
    payload = request.get_json(silent=True) or {}
    employee_id = str(payload.get("employeeId", "")).strip().upper()
    mobile = "".join(ch for ch in str(payload.get("mobile", "")) if ch.isdigit())
    new_password = str(payload.get("newPassword", ""))

    if not employee_id or not mobile or not new_password:
        return jsonify({"message": "Employee ID, registered mobile number, and new password are required"}), 400
    if len(new_password) < 8:
        return jsonify({"message": "New password must be at least 8 characters"}), 400

    employee = db.employees.find_one({"employeeId": employee_id})
    if not employee:
        return jsonify({"message": "Employee ID or registered mobile number does not match"}), 400

    stored_mobile = ""
    for field in ("mobile", "mobileNumber", "phone", "phoneNumber", "contactNumber"):
        value = employee.get(field)
        if value:
            stored_mobile = "".join(ch for ch in str(value) if ch.isdigit())
            if stored_mobile:
                break

    if not stored_mobile or stored_mobile != mobile:
        return jsonify({"message": "Employee ID or registered mobile number does not match. Contact HR if your mobile number is not registered."}), 400

    user = db.users.find_one({"username": employee_id.lower()})
    if not user:
        return jsonify({"message": "No login account was found for this employee"}), 404

    db.users.update_one(
        {"_id": user["_id"]},
        {"$set": {
            "passwordHash": generate_password_hash(new_password),
            "updatedAt": datetime.now(timezone.utc),
        }},
    )
    return jsonify({"message": "Password reset successfully. You can now sign in with your new password."}), 200


@auth_bp.post("/logout")
@jwt_required()
def logout():
    return jsonify({"message": "Logged out"})


def role_required(*roles):
    claims = get_jwt()
    if claims.get("role") not in roles:
        return jsonify({"message": "You do not have permission for this resource"}), 403
    return None
