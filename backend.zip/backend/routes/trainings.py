from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from bson import ObjectId
from flask import Blueprint, jsonify, request
from flask_jwt_extended import get_jwt, jwt_required


from db import db

trainings_bp = Blueprint(
    "trainings",
    __name__,
    url_prefix="/api/trainings"
)

trainings_collection = db["trainings"]
participants_collection = db["training_participants"]
employees_collection = db["employees"]

LOCAL_TZ = ZoneInfo("Asia/Kolkata")
LOCKED_STATUSES = ("Completed", "Cancelled")


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def now_utc():
    return datetime.now(timezone.utc)


def parse_date(value):
    """
    Accepts ISO strings, including the "YYYY-MM-DDTHH:MM" value produced by
    <input type="datetime-local">. Naive values are treated as IST.
    """
    if not value:
        return None

    if isinstance(value, datetime):
        parsed = value
    else:
        try:
            parsed = datetime.fromisoformat(
                str(value).replace("Z", "+00:00")
            )
        except ValueError:
            return None

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=LOCAL_TZ)

    return parsed


def to_object_id(value):
    try:
        return ObjectId(value)
    except Exception:
        return None


def employee_is_active(employee):
    return (employee.get("status") or "").strip().lower() != "inactive"


def clean_id_list(values):
    if not isinstance(values, list):
        return []

    return list(
        dict.fromkeys(
            str(value).strip()
            for value in values
            if value and str(value).strip()
        )
    )


def serialize_training(training, trainee_ids=None):
    if not training:
        return None

    return {
        "_id": str(training["_id"]),
        "title": training.get("title", ""),
        "content": training.get("content", ""),
        "trainingType": training.get("trainingType", ""),
        "trainerName": training.get("trainerName", ""),
        "trainerEmployeeId": training.get("trainerEmployeeId", ""),
        "trainerCategory": training.get("trainerCategory", ""),
        "venue": training.get("venue", ""),
        "trainingDate": training.get("startDate", training.get("trainingDate")),
        "startDate": training.get("startDate", training.get("trainingDate")),
        "endDate": training.get("endDate", training.get("startDate", training.get("trainingDate"))),
        "trainingMode": training.get("trainingMode", ""),
        "durationMinutes": training.get("durationMinutes", 0),
        "status": training.get("status", "Upcoming"),
        "departments": training.get("departments", []),
        "traineeIds": (
            trainee_ids
            if trainee_ids is not None
            else training.get("traineeIds", [])
        ),
    }


def get_participant_ids(training_id):
    rows = participants_collection.find(
        {"trainingId": training_id},
        {"_id": 0, "employeeId": 1}
    )
    return [row["employeeId"] for row in rows if row.get("employeeId")]


def sync_participants(training_id, employee_ids):
    """
    Makes the participant collection match employee_ids exactly:
    - removes participants that are no longer assigned
    - adds new ones (existing ones keep their attendance / progress)
    - mirrors the list onto training.traineeIds
    """
    existing_ids = set(get_participant_ids(training_id))
    wanted_ids = set(employee_ids)

    to_remove = existing_ids - wanted_ids
    to_add = [eid for eid in employee_ids if eid not in existing_ids]

    if to_remove:
        participants_collection.delete_many({
            "trainingId": training_id,
            "employeeId": {"$in": list(to_remove)}
        })

    if to_add:
        timestamp = now_utc()
        participants_collection.insert_many([
            {
                "trainingId": training_id,
                "employeeId": employee_id,
                "completionStatus": "Not Started",
                "attendance": "Pending",
                "feedbackStatus": "Pending",
                "createdAt": timestamp,
                "updatedAt": timestamp,
            }
            for employee_id in to_add
        ])

    trainings_collection.update_one(
        {"_id": ObjectId(training_id)},
        {"$set": {"traineeIds": employee_ids, "updatedAt": now_utc()}}
    )


def filter_active_employee_ids(employee_ids):
    if not employee_ids:
        return []

    found = employees_collection.find(
        {"employeeId": {"$in": employee_ids}}
    )

    active = {
        employee["employeeId"]
        for employee in found
        if employee_is_active(employee)
    }

    # keep the order the client sent
    return [eid for eid in employee_ids if eid in active]


# Searchable employee options for assigning trainees and choosing trainers.
@trainings_bp.get("/employee-options")
@jwt_required()
def employee_options():
    """Return only safe employee fields needed for trainer/trainee search."""
    projection = {
        "_id": 0,
        "employeeId": 1,
        "name": 1,
        "employeeName": 1,
        "fullName": 1,
        "department": 1,
        "designation": 1,
        "status": 1,
    }
    rows = []
    for employee in employees_collection.find({}, projection):
        employee_id = str(employee.get("employeeId") or employee.get("employee_id") or "").strip()
        if not employee_id or not employee_is_active(employee):
            continue
        name = str(employee.get("name") or employee.get("employeeName") or employee.get("fullName") or employee_id).strip()
        rows.append({
            "employeeId": employee_id,
            "name": name,
            "employeeName": name,
            "department": str(employee.get("department") or "").strip(),
            "designation": str(employee.get("designation") or "").strip(),
            "status": str(employee.get("status") or "Active").strip(),
        })
    rows.sort(key=lambda row: (row["name"].lower(), row["employeeId"].lower()))
    return jsonify(rows), 200


@trainings_bp.get("/<training_id>/responses")
@jwt_required()
def training_responses(training_id):
    claims = get_jwt()
    oid = to_object_id(training_id)
    if not oid:
        return jsonify({"message": "Invalid training ID."}), 400
    training = trainings_collection.find_one({"_id": oid})
    if not training:
        return jsonify({"message": "Training not found."}), 404
    role = claims.get("role")
    if role == "EMPLOYEE" and training.get("trainerEmployeeId") != claims.get("employeeId") and not participants_collection.find_one({"trainingId": training_id, "employeeId": claims.get("employeeId")}):
        return jsonify({"message": "You do not have access to this training."}), 403
    if role == "MANAGER" and claims.get("department") not in training.get("departments", []):
        ids = [x.get("employeeId") for x in employees_collection.find({"department": claims.get("department")}, {"employeeId": 1}) if x.get("employeeId")]
        if not participants_collection.find_one({"trainingId": training_id, "employeeId": {"$in": ids}}):
            return jsonify({"message": "You do not have access to this training."}), 403
    rows = []
    for participant in participants_collection.find({"trainingId": training_id}):
        employee = employees_collection.find_one({"employeeId": participant.get("employeeId")}, {"_id": 0, "name": 1, "department": 1}) or {}
        feedback = db.feedback.find_one({"trainingId": training_id, "employeeId": participant.get("employeeId")}, {"_id": 0}) or {}
        rows.append({"employeeId": participant.get("employeeId", ""), "employeeName": employee.get("name", participant.get("employeeId", "")), "department": employee.get("department", ""), "attendance": participant.get("attendance", "Pending"), "feedbackStatus": participant.get("feedbackStatus", "Pending"), "completionStatus": participant.get("completionStatus", "Not Started"), "ratings": feedback.get("ratings", {}), "remarks": feedback.get("remarks", ""), "majorLearning": feedback.get("majorLearning", ""), "submittedAt": feedback.get("submittedAt", "")})
    attendance_counts = {"Present": 0, "Absent": 0, "Partial": 0, "Pending": 0}
    feedback_counts = {"Submitted": 0, "Pending": 0}
    for row in rows:
        attendance_counts[row["attendance"] if row["attendance"] in attendance_counts else "Pending"] += 1
        feedback_counts["Submitted" if row["feedbackStatus"] == "Submitted" else "Pending"] += 1
    return jsonify({"training": serialize_training(training), "rows": rows, "attendanceCounts": attendance_counts, "feedbackCounts": feedback_counts}), 200


# --------------------------------------------------------------------------
# Trainings CRUD
# --------------------------------------------------------------------------

@trainings_bp.route("", methods=["GET"])
@jwt_required()
def get_trainings():
    claims = get_jwt()
    query = {}
    role = claims.get("role")
    employee_id = claims.get("employeeId")

    if role == "EMPLOYEE":
        assigned = participants_collection.distinct("trainingId", {"employeeId": employee_id})
        owned = [str(x["_id"]) for x in trainings_collection.find({"trainerEmployeeId": employee_id}, {"_id": 1})]
        valid_ids = [to_object_id(x) for x in set(assigned + owned) if to_object_id(x)]
        query["_id"] = {"$in": valid_ids}
    elif role == "MANAGER":
        ids = [x.get("employeeId") for x in employees_collection.find({"department": claims.get("department")}, {"employeeId": 1, "_id": 0}) if x.get("employeeId")]
        assigned = participants_collection.distinct("trainingId", {"employeeId": {"$in": ids}})
        valid_ids = [to_object_id(x) for x in assigned if to_object_id(x)]
        query["_id"] = {"$in": valid_ids}

    search = request.args.get("search", "").strip()
    training_type = request.args.get("trainingType", "").strip()
    status = request.args.get("status", "").strip()
    trainer = request.args.get("trainerName", "").strip()
    start_date = request.args.get("startDate", "").strip()
    end_date = request.args.get("endDate", "").strip()

    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"trainerName": {"$regex": search, "$options": "i"}},
            {"content": {"$regex": search, "$options": "i"}},
        ]
    if training_type:
        query["trainingType"] = training_type
    if status and status != "All":
        query["status"] = status
    if trainer:
        query["trainerName"] = {"$regex": trainer, "$options": "i"}

    date_range = {}
    if start_date:
        parsed = parse_date(start_date)
        if parsed:
            date_range["$gte"] = parsed.isoformat()
    if end_date:
        parsed = parse_date(end_date)
        if parsed:
            if len(end_date) == 10:
                parsed = parsed.replace(hour=23, minute=59, second=59)
            date_range["$lte"] = parsed.isoformat()
    if date_range:
        query["startDate"] = date_range

    trainings = list(trainings_collection.find(query).sort("startDate", -1))

    # one query for all participants instead of one per training
    participants_map = {}
    for row in participants_collection.find(
        {}, {"_id": 0, "trainingId": 1, "employeeId": 1}
    ):
        if row.get("trainingId") and row.get("employeeId"):
            participants_map.setdefault(
                row["trainingId"], []
            ).append(row["employeeId"])

    result = [
        serialize_training(
            training,
            participants_map.get(str(training["_id"]), [])
        )
        for training in trainings
    ]
    if role == "EMPLOYEE":
        participant_rows = {p.get("trainingId"): p for p in participants_collection.find({"employeeId": employee_id}, {"_id": 0, "trainingId": 1, "attendance": 1, "feedbackStatus": 1, "completionStatus": 1})}
        for row in result:
            p = participant_rows.get(row["_id"], {})
            row["myAttendance"] = p.get("attendance", "Pending")
            row["myFeedbackStatus"] = p.get("feedbackStatus", "Pending")
            row["myCompletionStatus"] = p.get("completionStatus", "Not Started")

    return jsonify(result), 200


@trainings_bp.route("", methods=["POST"])
@jwt_required()
def create_training():
    claims = get_jwt()
    if claims.get("role") not in {"HR_ADMIN", "MANAGER", "EMPLOYEE"}:
        return jsonify({"message": "You do not have permission to create training."}), 403
    data = request.get_json(silent=True) or {}

    title = str(data.get("title", "")).strip()
    if not title:
        return jsonify({"message": "Training title is required."}), 400

    start_date = data.get("startDate") or data.get("trainingDate")
    end_date = data.get("endDate") or start_date
    if not start_date or not parse_date(start_date) or not end_date or not parse_date(end_date):
        return jsonify({"message": "Start date and end date are required and must be valid."}), 400
    if parse_date(end_date) < parse_date(start_date):
        return jsonify({"message": "End date/time cannot be before start date/time."}), 400

    training_type = str(data.get("trainingType", "")).strip()
    if not training_type:
        return jsonify({"message": "Training type is required."}), 400

    trainer_category = data.get("trainerCategory", "Internal")
    trainer_employee_id = str(data.get("trainerEmployeeId", "") or "").strip()
    if claims.get("role") == "EMPLOYEE":
        trainer_category = "Internal"
        trainer_employee_id = str(claims.get("employeeId") or "").strip()
        trainer = employees_collection.find_one({"employeeId": trainer_employee_id}) or {}
        data["trainerName"] = trainer.get("name") or claims.get("name") or trainer_employee_id

    if trainer_category == "Internal" and not trainer_employee_id:
        return jsonify({
            "message": "Internal trainer must be an employee."
        }), 400

    try:
        duration = int(data.get("durationMinutes", 0) or 0)
    except (TypeError, ValueError):
        return jsonify({"message": "Invalid duration."}), 400

    departments = data.get("departments", [])
    if not isinstance(departments, list):
        departments = []

    # Status is stored as Upcoming / Completed / Cancelled only.
    # "Ongoing" is derived by the frontend from the date.
    status = data.get("status", "Upcoming")
    if status not in ("Upcoming", "Completed", "Cancelled"):
        status = "Upcoming"

    timestamp = now_utc()

    document = {
        "title": title,
        "content": str(data.get("content", "")).strip(),
        "trainingType": training_type,
        "trainerName": str(data.get("trainerName", "")).strip(),
        "trainerEmployeeId": (
            trainer_employee_id if trainer_category == "Internal" else ""
        ),
        "trainerCategory": trainer_category,
        "venue": str(data.get("venue", "")).strip(),
        "startDate": start_date,
        "endDate": end_date,
        "trainingDate": start_date,
        "trainingMode": data.get("trainingMode", "Offline"),
        "status": status,
        "departments": departments,
        "traineeIds": [],
        "createdAt": timestamp,
        "updatedAt": timestamp,
    }

    result = trainings_collection.insert_one(document)
    document["_id"] = result.inserted_id

    trainee_ids = filter_active_employee_ids(
        clean_id_list(data.get("traineeIds", []))
    )
    if trainee_ids:
        sync_participants(str(result.inserted_id), trainee_ids)
        document["traineeIds"] = trainee_ids

    return jsonify({
        "message": "Training created successfully.",
        "training": serialize_training(document)
    }), 201


@trainings_bp.route("/<training_id>", methods=["GET"])
@jwt_required()
def get_training(training_id):
    object_id = to_object_id(training_id)
    if not object_id:
        return jsonify({"message": "Invalid training ID."}), 400

    training = trainings_collection.find_one({"_id": object_id})
    if not training:
        return jsonify({"message": "Training not found."}), 404

    participants = list(
        participants_collection.find({"trainingId": training_id})
    )

    data = serialize_training(
        training,
        [p["employeeId"] for p in participants if p.get("employeeId")]
    )

    data["participants"] = [
        {
            "employeeId": item.get("employeeId", ""),
            "completionStatus": item.get("completionStatus", "Not Started"),
            "attendance": item.get("attendance", "Pending"),
            "feedbackStatus": item.get("feedbackStatus", "Pending"),
        }
        for item in participants
    ]

    return jsonify(data), 200


@trainings_bp.route("/<training_id>", methods=["PUT"])
@jwt_required()
def update_training(training_id):
    claims = get_jwt()
    object_id = to_object_id(training_id)
    if not object_id:
        return jsonify({"message": "Invalid training ID."}), 400
    current_training = trainings_collection.find_one({"_id": object_id})
    is_owner_trainer = claims.get("role") == "EMPLOYEE" and current_training and current_training.get("trainerEmployeeId") == claims.get("employeeId")
    if claims.get("role") not in {"HR_ADMIN", "MANAGER"} and not is_owner_trainer:
        return jsonify({"message": "Only HR, managers, or the assigned trainer can edit this training."}), 403

    data = request.get_json(silent=True) or {}

    allowed_fields = [
        "title", "content", "trainingType", "trainerName",
        "trainerEmployeeId", "trainerCategory", "venue", "startDate",
        "endDate", "trainingDate", "trainingMode", "status", "departments",
    ]

    update_data = {f: data[f] for f in allowed_fields if f in data}
    if is_owner_trainer:
        update_data.pop("trainerName", None)
        update_data.pop("trainerEmployeeId", None)
        update_data.pop("trainerCategory", None)

    if not update_data:
        return jsonify({"message": "No fields to update."}), 400

    if "trainingDate" in update_data:
        update_data["startDate"] = update_data.pop("trainingDate")
    if "startDate" in update_data and not parse_date(update_data["startDate"]):
        return jsonify({"message": "Invalid start date."}), 400
    if "endDate" in update_data and not parse_date(update_data["endDate"]):
        return jsonify({"message": "Invalid end date."}), 400
    current = trainings_collection.find_one({"_id": object_id}) or {}
    start_check = update_data.get("startDate", current.get("startDate", current.get("trainingDate")))
    end_check = update_data.get("endDate", current.get("endDate", start_check))
    if start_check and end_check and parse_date(end_check) < parse_date(start_check):
        return jsonify({"message": "End date/time cannot be before start date/time."}), 400
    if "startDate" in update_data:
        update_data["trainingDate"] = update_data["startDate"]

    update_data["updatedAt"] = now_utc()

    result = trainings_collection.update_one(
        {"_id": object_id}, {"$set": update_data}
    )

    if result.matched_count == 0:
        return jsonify({"message": "Training not found."}), 404

    training = trainings_collection.find_one({"_id": object_id})

    return jsonify({
        "message": "Training updated successfully.",
        "training": serialize_training(
            training, get_participant_ids(training_id)
        )
    }), 200


@trainings_bp.route("/<training_id>", methods=["DELETE"])
@jwt_required()
def delete_training(training_id):
    claims = get_jwt()
    role = claims.get("role")
    object_id = to_object_id(training_id)
    if not object_id:
        return jsonify({"message": "Invalid training ID."}), 400

    training = trainings_collection.find_one({"_id": object_id})
    if not training:
        return jsonify({"message": "Training not found."}), 404

    # HR can remove any training. Managers can remove trainings connected to
    # their department. An employee-trainer can remove only a training they created.
    if role == "HR_ADMIN":
        allowed = True
    elif role == "MANAGER":
        department = claims.get("department")
        assigned_ids = [row.get("employeeId") for row in employees_collection.find(
            {"department": department}, {"employeeId": 1, "_id": 0}
        ) if row.get("employeeId")]
        assigned_to_department = bool(participants_collection.find_one({
            "trainingId": training_id, "employeeId": {"$in": assigned_ids}
        }))
        allowed = department in (training.get("departments") or []) or assigned_to_department
    elif role == "EMPLOYEE":
        allowed = training.get("trainerEmployeeId") == claims.get("employeeId")
    else:
        allowed = False

    if not allowed:
        return jsonify({"message": "You do not have permission to delete this training."}), 403

    # Remove the training and its dependent records so it is fully removed from the portal.
    trainings_collection.delete_one({"_id": object_id})
    participants_collection.delete_many({"trainingId": training_id})
    db.feedback.delete_many({"trainingId": training_id})
    db.notifications.delete_many({"trainingId": training_id})
    db.evaluations.delete_many({"trainingId": training_id})

    return jsonify({"message": "Training and its related attendance, feedback, notifications, and evaluation records were deleted."}), 200


# --------------------------------------------------------------------------
# Assignment
# --------------------------------------------------------------------------

@trainings_bp.route("/<training_id>/participants", methods=["PUT"])
@jwt_required()
def update_participants(training_id):
    claims = get_jwt()
    object_id = to_object_id(training_id)
    if not object_id:
        return jsonify({"message": "Invalid training ID."}), 400

    training = trainings_collection.find_one({"_id": object_id})
    if not training:
        return jsonify({"message": "Training not found."}), 404
    role = claims.get("role")
    is_owner_trainer = role == "EMPLOYEE" and training.get("trainerEmployeeId") == claims.get("employeeId")
    if role not in {"HR_ADMIN", "MANAGER"} and not is_owner_trainer:
        return jsonify({"message": "Only HR, the department manager, or the assigned trainer can assign trainees."}), 403

    if training.get("status") in LOCKED_STATUSES:
        return jsonify({
            "message": f"Cannot change participants of a "
                       f"{training['status'].lower()} training."
        }), 400

    data = request.get_json(silent=True) or {}
    raw_ids = data.get("employeeIds", [])

    if not isinstance(raw_ids, list):
        return jsonify({"message": "employeeIds must be an array."}), 400

    valid_ids = filter_active_employee_ids(clean_id_list(raw_ids))
    if claims.get("role") == "MANAGER":
        allowed = {x.get("employeeId") for x in employees_collection.find({"department": claims.get("department")}, {"employeeId": 1, "_id": 0})}
        valid_ids = [x for x in valid_ids if x in allowed]

    sync_participants(training_id, valid_ids)

    return jsonify({
        "message": "Training assigned successfully.",
        "trainingId": training_id,
        "employeeIds": valid_ids,
        "count": len(valid_ids),
        "skipped": len(clean_id_list(raw_ids)) - len(valid_ids),
    }), 200


# --------------------------------------------------------------------------
# Complete / Cancel
# --------------------------------------------------------------------------

@trainings_bp.route("/<training_id>/complete", methods=["POST"])
@jwt_required()
def complete_training(training_id):
    claims = get_jwt()
    object_id = to_object_id(training_id)
    if not object_id:
        return jsonify({"message": "Invalid training ID."}), 400

    training = trainings_collection.find_one({"_id": object_id})
    if not training:
        return jsonify({"message": "Training not found."}), 404
    is_owner_trainer = claims.get("role") == "EMPLOYEE" and training.get("trainerEmployeeId") == claims.get("employeeId")
    if claims.get("role") not in {"HR_ADMIN", "MANAGER"} and not is_owner_trainer:
        return jsonify({"message": "Only HR, managers, or the assigned trainer can close this training."}), 403

    if training.get("status") == "Cancelled":
        return jsonify({
            "message": "A cancelled training cannot be completed."
        }), 400

    participant_rows = list(participants_collection.find({"trainingId": training_id}))
    if not participant_rows:
        return jsonify({"message": "Assign at least one trainee before completing this training."}), 400
    pending_attendance = [p for p in participant_rows if p.get("attendance", "Pending") in (None, "", "Pending")]
    if pending_attendance:
        return jsonify({"message": f"Attendance is still pending for {len(pending_attendance)} trainee(s)."}), 400
    pending_feedback = [p for p in participant_rows if p.get("attendance") in {"Present", "Partial"} and p.get("feedbackStatus") != "Submitted"]
    if pending_feedback:
        return jsonify({"message": f"Feedback is still pending for {len(pending_feedback)} attendee(s)."}), 400

    timestamp = now_utc()

    trainings_collection.update_one(
        {"_id": object_id},
        {"$set": {"status": "Completed", "completedAt": timestamp, "updatedAt": timestamp}}
    )

    participants_collection.update_many(
        {"trainingId": training_id},
        {"$set": {"completionStatus": "Completed", "updatedAt": timestamp}}
    )

    updated = trainings_collection.find_one({"_id": object_id})

    return jsonify({
        "message": "Training completed successfully.",
        "training": serialize_training(
            updated, get_participant_ids(training_id)
        )
    }), 200



@trainings_bp.route("/<training_id>/complete-self", methods=["POST"])
@jwt_required()
def complete_self(training_id):
    claims=get_jwt()
    if claims.get("role")!="EMPLOYEE":
        return jsonify({"message":"Only trainees can use this action"}),403
    if not to_object_id(training_id):
        return jsonify({"message":"Invalid training ID"}),400
    participant=participants_collection.find_one({"trainingId":training_id,"employeeId":claims.get("employeeId")})
    if not participant:
        return jsonify({"message":"You are not assigned to this training"}),404
    if participant.get("attendance") not in {"Present","Partial"}:
        return jsonify({"message":"Attendance must be marked before completing the training"}),400
    if participant.get("feedbackStatus")!="Submitted":
        return jsonify({"message":"Please submit feedback before marking this training complete"}),400
    participants_collection.update_one({"_id":participant["_id"]},{"$set":{"completionStatus":"Completed","completedAt":now_utc(),"updatedAt":now_utc()}})
    return jsonify({"message":"Training marked complete"})

@trainings_bp.route("/<training_id>/cancel", methods=["POST"])
@jwt_required()
def cancel_training(training_id):
    if get_jwt().get("role") not in {"HR_ADMIN", "MANAGER"}:
        return jsonify({"message": "Manager or HR Admin permission required."}), 403
    object_id = to_object_id(training_id)
    if not object_id:
        return jsonify({"message": "Invalid training ID."}), 400

    training = trainings_collection.find_one({"_id": object_id})
    if not training:
        return jsonify({"message": "Training not found."}), 404

    if training.get("status") == "Completed":
        return jsonify({
            "message": "A completed training cannot be cancelled."
        }), 400

    trainings_collection.update_one(
        {"_id": object_id},
        {"$set": {"status": "Cancelled", "updatedAt": now_utc()}}
    )

    updated = trainings_collection.find_one({"_id": object_id})

    return jsonify({
        "message": "Training cancelled successfully.",
        "training": serialize_training(
            updated, get_participant_ids(training_id)
        )
    }), 200


# --------------------------------------------------------------------------
# Progress
# NOTE: static route "/progress" is declared before dynamic routes that could
# shadow it; Flask matches static segments first, so this is safe.
# --------------------------------------------------------------------------

@trainings_bp.route("/progress", methods=["GET"])
@jwt_required()
def get_training_progress():
    claims = get_jwt()

    role = claims.get("role")
    employee_id = claims.get("employeeId")
    department = claims.get("department")

    query = {}
    if role == "EMPLOYEE":
        query["employeeId"] = employee_id

    participants = list(participants_collection.find(query))

    # batch-load related trainings and employees
    training_ids = {
        to_object_id(p.get("trainingId"))
        for p in participants
        if to_object_id(p.get("trainingId"))
    }
    employee_ids = {
        p.get("employeeId") for p in participants if p.get("employeeId")
    }

    trainings_map = {
        str(t["_id"]): t
        for t in trainings_collection.find({"_id": {"$in": list(training_ids)}})
    }
    employees_map = {
        e["employeeId"]: e
        for e in employees_collection.find(
            {"employeeId": {"$in": list(employee_ids)}}
        )
    }

    result = []

    for participant in participants:
        training = trainings_map.get(participant.get("trainingId"))
        employee = employees_map.get(participant.get("employeeId"))

        if not training or not employee:
            continue

        if (
            role == "MANAGER"
            and department
            and employee.get("department") != department
        ):
            continue

        result.append({
            "trainingId": str(training["_id"]),
            "trainingTitle": training.get("title", ""),
            "employeeId": participant.get("employeeId"),
            "employeeName": employee.get(
                "name", employee.get("employeeName", "")
            ),
            "department": employee.get("department", ""),
            "attendance": participant.get("attendance", "Pending"),
            "completionStatus": participant.get(
                "completionStatus", "Not Started"
            ),
            "feedbackStatus": participant.get("feedbackStatus", "Pending"),
            "updatedAt": participant.get("updatedAt"),
        })

    return jsonify(result), 200


@trainings_bp.route("/<training_id>/progress", methods=["PUT"])
@jwt_required()
def update_training_progress(training_id):
    if not to_object_id(training_id):
        return jsonify({"message": "Invalid training ID."}), 400

    data = request.get_json(silent=True) or {}

    employee_id = data.get("employeeId")
    if not employee_id:
        return jsonify({"message": "employeeId is required."}), 400

    update_fields = {}
    for field in ("completionStatus", "attendance", "feedbackStatus"):
        if data.get(field):
            update_fields[field] = data[field]

    if not update_fields:
        return jsonify({
            "message": "Provide completionStatus, attendance or feedbackStatus."
        }), 400

    update_fields["updatedAt"] = now_utc()

    result = participants_collection.update_one(
        {"trainingId": training_id, "employeeId": employee_id},
        {"$set": update_fields}
    )

    if result.matched_count == 0:
        return jsonify({
            "message": "Employee is not assigned to this training."
        }), 404

    return jsonify({
        "message": "Training progress updated successfully."
    }), 200